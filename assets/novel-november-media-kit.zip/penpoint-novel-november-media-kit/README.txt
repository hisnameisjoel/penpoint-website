PENPOINT & NOVEL NOVEMBER: MEDIA KIT
====================================

Thank you for helping spread the word!

This kit has eight share cards for Penpoint & Novel November, each in two sizes:

  square-1080x1080/   for Instagram and Facebook posts, Bluesky, X, Threads, Mastodon
  tall-1080x1920/     for Stories, Reels, TikTok, and Pinterest
  logos/              the Penpoint logo (see "The Penpoint logo" below)

  01-offer         Write your novel. Entirely free through November.
  02-calendar      October: plot it. November: write 50,000 words.
  03-no-strings    No account. No credit card. Export any time.
  04-cast          Keep every character, place, and timeline straight.
  05-daily-goal    1,667 words a day. Penpoint keeps the count.
  06-week-two      Week two is where novels die. Bring a plan.
  07-cloud         Penpoint Cloud opens November 1. Free all month.
  08-share         Know a writer starting a novel this November? Send them this.

SHARE.md has ready-to-post captions (short, medium, and a 4-post thread),
the hashtag list, alt text for every card, and the link to use.

HOW TO USE IT
-------------
1. Pick a card (or a few) in the size that fits where you post.
2. Copy a caption from SHARE.md, or write your own.
3. Paste the alt text from SHARE.md so everyone can enjoy the post.
4. Share the link: penpoint.app/novel-november

THE PENPOINT LOGO (logos/)
--------------------------
Need the Penpoint logo for a post, a video, or an article? Use these instead
of a screenshot of the website.

  logos/mark/             the quill on its own (square)
  logos/horizontal/       the quill beside the word "Penpoint"
  logos/stacked/          the quill above the word "Penpoint"
  logos/novel-november/   "Penpoint & Novel November" in one line
  logos/app-icon/         the Penpoint app icon (512 and 1024 px PNG)

Every logo comes in four colorways, in the file name:

  color-light   orange quill, dark word. For light backgrounds.
  color-dark    gold quill, cream word. For dark backgrounds.
  black         solid black, for one-color print.
  white         solid white, for photos and dark backgrounds.

Use SVG when you can: it stays sharp at any size, and it works in Canva,
Figma, Illustrator, and most video editors. The PNG files are transparent
(no background) in several sizes; the number in the file name is the width
in pixels.

Colors
  Penpoint orange   #CD6E2C
  Ink               #29241E
  Gold (on dark)    #DDA964
  Cream (on dark)   #F3E7CE

A few simple rules
  Leave clear space around the logo, about the height of the quill.
  Do not stretch, recolor, rotate, or add effects (shadows, glows, outlines).
  The name is "Penpoint": one word, capital P.

The logos were drawn entirely in code. No AI-generated art.
Questions: support@penpoint.app

THE VIDEO
---------
A short silent video (about 30 seconds, vertical and square) is not in this
zip to keep the download small. It is shared separately and linked from
penpoint.app/novel-november.

SMALL PRINT
-----------
Every card, the logos, and the video were drawn entirely in code for Penpoint.
No stock images and no AI-generated art. You are welcome to share them as they are.

Penpoint is not affiliated with any writing organization.
