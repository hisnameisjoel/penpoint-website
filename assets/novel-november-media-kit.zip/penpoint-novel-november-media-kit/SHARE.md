# Penpoint & Novel November: share sheet

Everything you need to tell a writer friend about Penpoint & Novel November. Copy what you like,
change what you want, and post the pictures from this kit.

## The link

```
https://penpoint.app/novel-november
```

Short form for pictures and captions: **penpoint.app/novel-november**

## The facts, in one place

- **Free through November.** The free trial runs until December 1. Start late and you still get at
  least 14 days.
- **No account. No credit card. Nothing to cancel.** Your books stay on your computer, and you can
  export to Word, PDF, Markdown, or plain text any time.
- **Windows, macOS, and Linux.** Penpoint is desktop software.
- **Penpoint Cloud opens November 1** and is free for everyone all November: backup, sync across
  your computers, and the Minipen phone companion.
- **After November:** Penpoint is $40 once (no subscription). Cloud becomes an optional paid
  subscription.

## Hashtags, ranked

Use the first four almost everywhere, then add the platform ones where they fit.

1. `#preptober` (October planning; strongest until November 1)
2. `#writingcommunity`
3. `#writerscommunity`
4. `#amwriting`
5. `#writertok` (TikTok)
6. `#writersofinstagram` (Instagram)
7. `#novelwriting`
8. `#writingchallenge`
9. `#penpoint`

**Leave out `#novelnovember` and `#novnov`.** Other writing events use them, and tagging them would
suggest a connection that does not exist.

## Three posts, ready to go

### Short (fits anywhere, X included)

> Writing a novel this November? Penpoint is a new writing app that keeps your characters, plot, and manuscript all in one place. It's free through December 1, so you can plan your story and write the whole book without paying a thing. Find out more: https://penpoint.app/novel-november

### Medium (about 500 characters)

> The November novel challenge is still on. Bring Penpoint.
>
> Penpoint is desktop writing software for novelists (Windows, macOS, Linux), and it is free through November. No account, no credit card, and you can export to Word, PDF, Markdown, or plain text any time.
>
> Plot in October with the Corkboard, characters, places, and a timeline. Write in November with a daily word goal that keeps the count.
>
> Penpoint Cloud opens November 1, free all month.
>
> https://penpoint.app/novel-november

### Thread (4 posts)

> **1/4** Starting a novel this November? The challenge is still on, and Penpoint is free for all of it. No account, no credit card, nothing to cancel. penpoint.app/novel-november
>
> **2/4** October is for planning. Lay out chapters on the Corkboard, build your cast and places, and keep a timeline, all in the same app as your manuscript. The Minipen sidebar keeps it beside your draft while you write.
>
> **3/4** November is 1,667 words a day. Set it as your daily goal on the Progress page and Penpoint keeps the count. Everything autosaves, and you can export to Word, PDF, Markdown, or plain text any time.
>
> **4/4** Penpoint Cloud opens November 1, free all month: backup, sync across your computers, and your novel on your phone. Windows, macOS, Linux. https://penpoint.app/novel-november

## Alt text for the pictures

Each card comes in two sizes (square and tall); the alt text is the same for both.

- **01 The offer:** "Penpoint & Novel November. Write your novel. A laptop shows Penpoint's writing screen with Chapter One open, and a yellow sticky note reads: Entirely free through November. penpoint.app/novel-november"
- **02 The calendar:** "Two month cards. October, Preptober: Plot it. Build it. Meet your cast, with planning days checked off. November, Write: Write 50,000 words, with a word-count bar filled in for every day. penpoint.app/novel-november"
- **03 No strings:** "A ruled index card with three checked lines: No account. No credit card. Export any time. Below it: Word, PDF, Markdown, plain text, and tags for Windows, macOS, and Linux. penpoint.app/novel-november"
- **04 The cast:** "Keep every character, place, and timeline straight while you draft. A manuscript page with linked character and place names sits beside Penpoint's Minipen sidebar showing the character Aldric, and a timeline strip runs below. penpoint.app/novel-november"
- **05 Daily goal:** "1,667 words a day. Penpoint keeps the count. Penpoint's Daily Goal panel shows 1,667 of 1,667 words and Goal reached, beside a 12-day writing streak and a sticky note: Day 12. Still going! penpoint.app/novel-november"
- **06 Week two:** "Week two is where novels die. Bring a plan. A corkboard of chapter cards, 7 through 12, each with a short summary, and a sticky note pointing at chapter 7: Day 8, start here. penpoint.app/novel-november"
- **07 Penpoint Cloud:** "Penpoint Cloud opens November 1. A blue sticky note reads: Free all month. A desktop computer, a laptop, and a phone all show the same novel. Your novel on every computer, and your phone. penpoint.app/novel-november"
- **08 Share:** "Know a writer starting a novel this November? Send them this. A paper airplane flies toward the link penpoint.app/novel-november. Small print: Penpoint is not affiliated with any writing organization."

## The fine print

Penpoint is not affiliated with any writing organization.

Penpoint & Novel November is Penpoint's own free-writing offer.
